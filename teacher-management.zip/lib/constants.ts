export const TASK_STATUSES = ["To Do", "In Progress", "Done"]
export const PRIORITY_LEVELS = ["Low", "Medium", "High"]
export const DEPARTMENTS = [
  "Fnd-01",
  "Fnd-02",
  "Fnd-03",
  "Fnd-04",
  "Fnd-05",
  "Fnd-06",
  "Fnd-07",
  "Fnd-08",
  "Fnd-09",
  "Fnd-10",
  "Fnd-11",
  "Fnd-12",
  "Fnd-13",
  "Fnd-14",
]

